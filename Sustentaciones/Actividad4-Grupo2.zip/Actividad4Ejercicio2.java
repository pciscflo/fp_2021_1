package com.fundamentos;

import java.util.ArrayList;

public class Actividad4Ejercicio2 {

    public static String codigo = "302823511233ABCH12452018/08/29-17:01:33102";
    public static String[] codigos = {"302823511233ABCH12452018/08/29-17:01:33102", "302823611233ABCH12452018/08/29-17:01:33102", "303823511233ABCH12452018/08/29-17:01:33102", "302826411233ABCH12452018/07/29-17:01:33102" };


    public static void main(String[] args) {
        System.out.println("La transacción es: " + operacionCliente());
        System.out.println("La operación mas frecuente es: " + operacionMasFrecuente());
        System.out.println("Transacciones por fechas: " + transaccionesPorFecha("2018/08/29"));
        System.out.println("Transacciones por cuenta: " + transaccionesPorCuenta("823511233"));
    }


    public static String operacionCliente() {

        String tipoOperacion = "";

        if ("302".equalsIgnoreCase(codigo.substring(0, 3))) {
            tipoOperacion = "Afiliación";
        } else if ("303".equalsIgnoreCase(codigo.substring(0, 3))) {
            tipoOperacion = "Bloqueo";
        } else {
            tipoOperacion = "No es una operación válida";
        }

        return tipoOperacion;
    }


    public static String operacionMasFrecuente() {

        int afiliacion = 0;
        int bloqueo = 0;
        String operacion;


        for (int i = 0; i < codigos.length; i++) {
            if ("302".equals(codigos[i].substring(0, 3))) {
                afiliacion++;
            } else {
                bloqueo++;
            }
        }

        if (afiliacion > bloqueo) {
            operacion = "Afiliación";
        } else {
            operacion = "Bloqueo";
        }

        return operacion;
    }

    public static ArrayList<String> transaccionesPorFecha(String fecha) {

        ArrayList<String> transacciones = new ArrayList<>();


        for (int i = 0; i < codigos.length; i++) {
            if (fecha.equals(codigos[i].substring(20, 30))) {
                transacciones.add(codigos[i].substring(0, 3));
            }
        }

        return transacciones;
    }

    public static ArrayList<String> transaccionesPorCuenta(String cuenta) {

        ArrayList<String> transacciones = new ArrayList<String>();


        for (int i = 0; i < codigos.length; i++) {
            if (cuenta.equalsIgnoreCase(codigos[i].substring(3, 12))) {
                transacciones.add(codigos[i].substring(0, 3));
            }
        }

        return transacciones;
    }


}
