package com.fundamentos;

public class Actividad4Ejericio1 {

    static String[] codigos = {"PLIP1731P2143P3298BN008"};

    public static void main(String[] args) {

        String codigo = "PLIP1731P2143P3298BN008";

        System.out.println("Número de votos del tipo \"Blanco o nulo\": " + codigo.substring(20, 23));
        System.out.println("Número de códigos del distrito: " + obtenerCantidadCodigosDistritos("PLI"));
        System.out.println("Número votos por códigos del distrito y caandidato: " + obtenerCantidadVotosDistritoCandidato("PLI", "P3"));

    }


    public static int obtenerCantidadCodigosDistritos(String distrito) {
        int contador = 0;
        for (int i = 0; i < codigos.length; i++) {
            if (codigos[i].substring(0, 3).equals(distrito)) {
                contador++;
            }
        }
        return contador;
    }


    public static int obtenerCantidadVotosDistritoCandidato(String distrito, String candidato) {
        int votos = 0;
        for (int i = 0; i < codigos.length; i++) {
            if (codigos[i].substring(0, 3).equals(distrito)) {
                if (("P1").equals(candidato)) {
                    votos = votos + Integer.parseInt(codigos[i].substring(5, 8));
                } else if (("P2").equals(candidato)) {
                    votos = votos + Integer.parseInt(codigos[i].substring(10, 13));
                } else {
                    votos = votos + Integer.parseInt(codigos[i].substring(15, 18));
                }
            }
        }
        return votos;
    }


}
