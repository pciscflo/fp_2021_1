package com.fundamentos;

public class Actividad4Ejercicio3 {

        public static int[] puntajes = {60, 51, 71, 84, 99, 65};

        public static int[] puntajesPromedios = {65, 65, 80, 65, 74, 69, 65, 82, 84, 84};

        public static void main(String[] args) {
            System.out.println("Puntaje promedio de calificación es: " + calcularPuntajePromedio(puntajes));
            System.out.println("Porcentaje de vinos Buenos: " + calcularPorcentajeVinosBuenos(puntajesPromedios));
        }


        public static double calcularPuntajePromedio(int[] puntajes) {

            int sumaPuntajes = 0;

            for (int i = 0; i < puntajes.length; i++) {
                sumaPuntajes = sumaPuntajes + puntajes[i];
            }

            return (sumaPuntajes / puntajes.length);

        }

        public static double calcularPorcentajeVinosBuenos(int[] puntajesPromedios) {

            int vinosBuenos = 0;

            for (int i = 0; i < puntajesPromedios.length; i++) {
                if (puntajesPromedios[i] >= 80 && puntajesPromedios[i] <= 84) {
                    vinosBuenos++;
                }

            }

            return ((vinosBuenos * 100) / puntajesPromedios.length);

        }
    }
