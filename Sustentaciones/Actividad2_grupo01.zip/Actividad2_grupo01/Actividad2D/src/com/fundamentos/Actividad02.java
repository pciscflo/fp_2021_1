package com.fundamentos;
/* una empresa vende helados de 2 marcas distintas, la 1ra marca QUE RICO cuenta con los helados de un litro con
los sabores de fresa a S/. 5 soles, vainilla a S/. 4 soles y Chocolate a S/.8 soles, la 2da. marca es FREEZER
cuenta con los helados de un litro con los sabores de fresa a S/. 6 soles, vainilla a S/. 5 soles y Chocolate a
S/.10 soles,cabe resaltar que el descuento se aplica para un determinado sabor de helado de ambas marcas por
compras mayores a 2 unid. 10%, por compras mayores de 6 unid. 15%, y por compras mayores 10 unid. 20%.
 */

import java.util.Scanner;

public class Actividad02 {

    public static double calculopreciohelado(String marcahelado,String helado) {
        double precio=0;
        switch (marcahelado){
            case "QUE RICO":
                if (helado.equals("Fresa") || helado.equals("FRESA") || (helado.equals("fresa"))){
                    precio=5;
                }
                else if (helado.equals("Vainilla") || helado.equals("VAINILLA") || (helado.equals("vainilla"))) {
                    precio = 4;
                }
                else if (helado.equals("Chocolate") || helado.equals("CHOCOLATE") || (helado.equals("chocolate"))){
                    precio = 8;
                }
                break;
            case "FREEZER":
                if (helado.equals("Fresa") || helado.equals("FRESA")|| (helado.equals("fresa"))){
                    precio=6;
                }
                else if (helado.equals("Vainilla") || helado.equals("VAINILLA")|| (helado.equals("vainilla"))) {
                    precio =5;
                }
                else if (helado.equals("Chocolate") || helado.equals("CHOCOLATE")|| (helado.equals("chocolate"))) {
                    precio =10;
                }
        }
        return precio;
    }
    public static double calculodeldescuento(int cantidad,  double precio) {
        double pagodescontado=0, porcedescuento,descuento=0;

        if (cantidad >= 2 && cantidad < 6) {
            descuento=0.1;
        }
        else if (cantidad >= 6 && cantidad < 10) {
            descuento=0.15;
        }
        else if(cantidad >= 10) {
            descuento=0.20;
        }
        porcedescuento = Math.round(descuento*100);
        System.out.println("\nUsted tiene un descuento de "+porcedescuento+ " %");

        pagodescontado=cantidad*precio*(1-descuento);

        return pagodescontado;

    }
    public static void main(String[] args) {

        Scanner entrada = new Scanner(System.in);
        // Definimos variabes
        String sabor_helado, nombre_marca_helado;
        double precio_helado=0, pago_con_descuento;
        int cantidad_helado;

        // definicion de productos
        System.out.println("\nVENTA DE HELADOS DE LA MARCA 'QUE RICO' ");
        System.out.println("\nHelados disponible:");
        System.out.println("Fresa         -    5 soles");
        System.out.println("Vainilla      -    4 soles");
        System.out.println("Chocolate     -    8 soles");

        System.out.println("\nVENTA DE HELADOS DE LA MARCA 'FREEZER' ");
        System.out.println("\nHelados disponible:");
        System.out.println("Fresa         -    6 soles");
        System.out.println("Vainilla      -    5 soles");
        System.out.println("Chocolate     -    10 soles");

        // captura de datos
        System.out.print("\nIngrese el nombre de la marca del helado de su eleccion: ");
        nombre_marca_helado = entrada.nextLine();

        System.out.print("\nIngrese el nombre del sabor del helado de su eleccion: ");
        sabor_helado = entrada.nextLine();

        //resultado
        precio_helado=calculopreciohelado(nombre_marca_helado,sabor_helado);// ingresamos la marca y el sabor del helado para obtener su precio

        if (precio_helado!=0){//nos permite identificar si se ingreso un nombre de marca o sabor correcto
            System.out.println("\nEligio el helado de "+sabor_helado+" el cual cuesta "+precio_helado+" soles.\n");

            System.out.print("Ingrese la cantidad de helados que desea comprar: ");
            cantidad_helado= entrada.nextInt();
            pago_con_descuento=calculodeldescuento(cantidad_helado, precio_helado);

            System.out.println("\nEl monto total a pagar es: "+pago_con_descuento+" soles");
        }
        else{
            System.out.println("No contamos con esa marca o sabor");
        }

    }



}
