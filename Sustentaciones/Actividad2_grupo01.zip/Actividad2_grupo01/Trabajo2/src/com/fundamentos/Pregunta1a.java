package com.fundamentos;

import java.util.Scanner;

public class Pregunta1a
{
    public static double adicional(String bloque_adi) {

        double precio_adi;

        switch (bloque_adi){
            case "max":
                precio_adi = 10;
                break;
            case "fox":
                precio_adi = 15;
                break;
            case "hbo":
                precio_adi = 20;
                break;
            default:
                precio_adi = 0;
        }

        return (precio_adi);
    }

    public static void main(String[] args)
    {
        Scanner scanner = new Scanner (System.in);
        String tipo_bloqueadicional;
        double pago_bloqueadicional;
        System.out.println("Ingrese paquete adicional:");
        tipo_bloqueadicional = scanner.nextLine();
        pago_bloqueadicional= adicional(tipo_bloqueadicional);
        System.out.println("El precio de venta del paquete adicional es de " + pago_bloqueadicional+" soles.");

    }
}
