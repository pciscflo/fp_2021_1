package com.fundamentos;

import java.util.Scanner;

public class Pregunta1
{
     public static double paquete(String tipo_paque, String empresa) {

        double precio_paquete=0;

        switch (tipo_paque){
            case "estandar":
                if (empresa.equals("movistar")){
                   precio_paquete = 120;}
                else if (empresa.equals("claro")){
                    precio_paquete=90;}
                else if (empresa.equals("entel")){
                    precio_paquete=80; }
                break;
            case "triobasico":
                if (empresa.equals("movistar")){
                    precio_paquete = 150;}
                else if (empresa.equals("claro")){
                    precio_paquete=120;}
                else if (empresa.equals("entel")){
                    precio_paquete=120; }
                break;
            case "trioilimitado":
                if (empresa.equals("movistar")){
                    precio_paquete = 180;}
                else if (empresa.equals("claro")){
                    precio_paquete=150;}
                else if (empresa.equals("entel")){
                    precio_paquete=160; }
                break;
        }

        return (precio_paquete);
    }

    public static double adicional(String bloque_adi) {

    double precio_adi;

    switch (bloque_adi){
        case "max":
            precio_adi = 10;
            break;
        case "fox":
            precio_adi = 15;
            break;
        case "hbo":
            precio_adi = 20;
            break;
        default:
            precio_adi = 0;;
    }

    return (precio_adi);
}


    public static void main(String[] args)
    {
        String opcion_paquete,opcion_empresa,o_adi, mensaje=null,resp;
        double p_adi=0,precio_total,p_paquete;
        Scanner scanner = new Scanner (System.in);
        System.out.println("Ingrese opción de paquete:");
        opcion_paquete = scanner.nextLine();
        System.out.println("Ingrese opción de empresa:");
        opcion_empresa = scanner.nextLine();
        System.out.println("Desea paquete adicional:");
        resp = scanner.nextLine();

        if(resp.equals("si")){
            mensaje="Escoger paquete adicional:";
            System.out.println(mensaje);
            o_adi=scanner.nextLine();
            p_adi=adicional(o_adi);
        }
        else if (resp.equals("no")){
            p_adi=0;
        }

        System.out.println("precio de paquete adicional: "+ p_adi + " soles.");

        p_paquete=paquete(opcion_paquete,opcion_empresa);
        precio_total=p_paquete + p_adi;

        System.out.println("Precio de venta de paquete: "+ p_paquete + " soles.");
        System.out.println("Precio de venta total: "+ precio_total + " soles.");


    }
}
