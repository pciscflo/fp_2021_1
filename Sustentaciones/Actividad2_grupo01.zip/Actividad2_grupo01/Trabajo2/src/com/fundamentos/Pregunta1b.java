package com.fundamentos;

import java.util.Scanner;

public class Pregunta1b
{
    public static double paquete(String tipo_paque, String empresa) {

        double precio_paquete=0;

        switch (tipo_paque){
            case "estandar":
                if (empresa.equals("movistar")){
                    precio_paquete = 120;}
                else if (empresa.equals("claro")){
                    precio_paquete=90;}
                else if (empresa.equals("entel")){
                    precio_paquete=80; }
                break;
            case "triobasico":
                if (empresa.equals("movistar")){
                    precio_paquete = 150;}
                else if (empresa.equals("claro")){
                    precio_paquete=120;}
                else if (empresa.equals("entel")){
                    precio_paquete=120; }
                break;
            case "trioilimitado":
                if (empresa.equals("movistar")){
                    precio_paquete = 180;}
                else if (empresa.equals("claro")){
                    precio_paquete=150;}
                else if (empresa.equals("entel")){
                    precio_paquete=160; }
                break;
        }

        return (precio_paquete);
    }

    public static void main(String[] args)
    {
        String opcion_paquete, opcion_empresa;
        double pago_paquete;
        Scanner scanner = new Scanner (System.in);
        System.out.println("Ingrese opción de paquete:");
        opcion_paquete = scanner.nextLine();
        System.out.println("Ingrese opción de empresa:");
        opcion_empresa = scanner.nextLine();

        pago_paquete= paquete(opcion_paquete,opcion_empresa);
        System.out.println("Precio de venta de paquete es de "+ pago_paquete+ " soles.");

    }

}
