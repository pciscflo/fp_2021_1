package com.upc.fundamentos;

import javax.swing.plaf.synth.SynthOptionPaneUI;
import java.util.Scanner;

public class Main {

    static String[] resultadosvotacion = {"PLIP1731P2143P3298BN008","PLIP1431P2043P3998BN010","PLIP1831P4143P2298BN022","SNBP1456P2100P3387BN010","MIRP1320P2090P3234BN020",
            "BREP1189P2156P3265BN025", "SNBP1254P2200P3212BN011", "MIRP1273P2345P3265BN014","MIRP1310P2190P4234BN122","CHOP1312P2145P3243BN013","CHOP1202P2765P3143BN022"};


    public static int obtenerVotosBlancosNulos() {

        int suma = 0;
        for (int i = 0; i < resultadosvotacion.length; i++) {
            suma += Integer.parseInt(resultadosvotacion[i].substring(21, 23));

        }
        return suma;
    }

    public static int obtenerDistrito(String distrito) {

        int contador = 0;
        for (int i = 0; i < resultadosvotacion.length; i++) {
            if (resultadosvotacion[i].substring(0, 3).equals(distrito)) {
                contador++;
            }
        }
        return contador;
    }

    public static int obtenerVotosporCandidatoP1(String distrito) {

        int suma=0;
        for (int i = 0; i < resultadosvotacion.length; i++) {
            if(resultadosvotacion[i].substring(0,3).equals(distrito)) {
                suma+= Integer.parseInt(resultadosvotacion[i].substring(5,8));
            }
        }
        return suma;
    }

    public static int obtenerVotosporCandidatoP2(String distrito){

        int suma=0;
        for (int i = 0; i < resultadosvotacion.length; i++) {
            if(resultadosvotacion[i].substring(0,3).equals(distrito)) {
                suma+= Integer.parseInt(resultadosvotacion[i].substring(10,13));
            }
        }
        return suma;
    }

    public static int obtenerVotosporCandidatoP3(String distrito){

        int suma=0;
        for (int i = 0; i < resultadosvotacion.length; i++) {
            if(resultadosvotacion[i].substring(0,3).equals(distrito)) {
                suma+= Integer.parseInt(resultadosvotacion[i].substring(15,18));
            }
        }
        return suma;
    }

    public static void main(String[] args) {

        String distrito;
        Scanner sc = new Scanner(System.in);


        System.out.println("El total de votos en Blanco y Nulos es:" +obtenerVotosBlancosNulos());
        System.out.println("-----------------------------------");
        System.out.println("El Total de codigos para el distrito de San Borja es:" +obtenerDistrito("SNB"));
        System.out.println("El Total de codigos para el distrito de Miraflores es:" +obtenerDistrito("MIR"));
        System.out.println("El Total de codigos para el distrito de Chorrillos es:" +obtenerDistrito("CHO"));
        System.out.println("El Total de codigos para el distrito de Breña es:" +obtenerDistrito("BRE"));
        System.out.println("El Total de codigos para el distrito de Pueblo Libre es:" +obtenerDistrito("PLI"));
        System.out.println("-----------------------------------");
        System.out.println("Ingrese el distrito al cual quiere contabilizar los votos por candidato:");
        distrito = sc.nextLine();
        System.out.println("Candidato1:"+obtenerVotosporCandidatoP1(distrito));
        System.out.println("Candidato2:"+obtenerVotosporCandidatoP2(distrito));
        System.out.println("Candidato3:"+obtenerVotosporCandidatoP3(distrito));
        //System.out.println(obtenerVotosporCandidatoP1("SNB"));
        //System.out.println(obtenerVotosporCandidatoP2("SNB"));
        //System.out.println(obtenerVotosporCandidatoP3("SNB"));
    }
}
