package com.upc.fundamentos;

import java.util.Scanner;

public class Pregunta1b {
    public static void main(String[] args) {
        Scanner escaner = new Scanner(System.in);
        String[] codigo = {"PLIP1731P2143P3298BN008", "PLIP1731P2143P3298BN008"};
        String votosBN, votos = "";
        String distrito, candidato;
        int contador = 0, acumulador = 0;

        //1.
        votosBN = codigo[0].substring(20, 23);
        System.out.println("Número de votos Blancos o Nulos: " + votosBN);

        //2.
        System.out.println("Ingrese distrito:");
        distrito = escaner.nextLine();
        for (int i = 0; i < codigo.length; i++) {
            if (distrito.equals(codigo[i].substring(0, 3))) {
                contador += 1;
            }
        }
        System.out.println("La cantidad de distritos es: " + contador);

        //3.
        System.out.println("Ingrese distrito:");
        distrito = escaner.nextLine();
        System.out.println("Ingrese candidato:");
        candidato = escaner.nextLine();


        for (int i = 0; i < codigo.length; i++) {
            if (distrito.equals(codigo[i].substring(0, 3))) {
                if (candidato.equals("P1")) {
                    votos = codigo[i].substring(5, 8);
                    acumulador += Integer.parseInt(votos);
                } else if (candidato.equals("P2")) {
                    votos = codigo[i].substring(10, 13);
                    acumulador += Integer.parseInt(votos);
                } else if (candidato.equals("P3")) {
                    votos = codigo[i].substring(15, 18);
                    acumulador += Integer.parseInt(votos);
                }
            }
        }

        System.out.println("La cantidad de votos para el candidato es: " + acumulador);
    }


}

