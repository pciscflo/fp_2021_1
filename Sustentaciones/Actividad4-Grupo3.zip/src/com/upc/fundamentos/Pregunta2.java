package com.upc.fundamentos;

import java.util.Scanner;

public class Pregunta2 {
    public static void main(String[] args) {
        Scanner escaner = new Scanner(System.in);
        String dato, resultado = "";
        int orden;
        String[] codigo = {
                "302823511233ABCH12452018/08/29-17:01:33102",
                "303823511233ABCH12452018/08/31-11:01:33103",
                "302823511244ABCH12462018/08/31-14:05:32104",
                "303823511245ABCH12472018/08/31-16:01:33105",
                "302823511396ABCH12482018/08/31-22:09:33106",
                "303823511268ABCH12492018/08/31-23:50:20107"};

        // 1.
        System.out.println("Nro orden de transacción:");
        orden = escaner.nextInt() - 1;
        dato = codigo[orden].substring(0, 3);
        if (dato.equals("302")) {
            resultado = "Afiliación";
        } else if (dato.equals("303")) {
            resultado = "Bloqueo";
        }
        System.out.println("El tipo de operación es: " + resultado);

        // 2.
        int contadorAfil=0, contadorBloq=0;
        for (int i = 0; i < codigo.length; i++) {
            if (codigo[i].substring(0,3).equals("302")){
                contadorAfil++;
            }else if (codigo[i].substring(0,3).equals("303")){
                contadorBloq++;
            }
        }
        if (contadorAfil>contadorBloq){
            System.out.println("La transacción más frecuente es 302");
        }else if (contadorBloq>contadorAfil){
            System.out.println("La transacción más frecuente es 303");
        }else{
            System.out.println("La transacciones más frecuentes son 302 y 303");
        }

        // 3.
        String fecha;
        fecha= escaner.nextLine();
        System.out.println("Ingrese fecha:");
        fecha= escaner.nextLine();
        for (int i=0; i< codigo.length;i++ ){
            if (fecha.equals(codigo[i].substring(20,30))){
                System.out.println(codigo[i]);
            }
        }

        // 4.
        String cuenta;
        System.out.println("Ingrese cuenta:");
        cuenta= escaner.nextLine();
        for (int i=0; i< codigo.length;i++ ){
            if (cuenta.equals(codigo[i].substring(3,12))){
                System.out.println(codigo[i]);
            }
        }

    }


}
