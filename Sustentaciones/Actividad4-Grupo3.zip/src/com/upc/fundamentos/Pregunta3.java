package com.upc.fundamentos;

public class Pregunta3 {
    public static void main(String[] args) {
        int[] calificacionVino = {65,70,80,79,68,70,81,71,76,67};
        int[] promediosVino = {80,78,81,75,86,90,88,72,83,84};
        String[] nombreVino = {"Catena","Penfolds","Torres","19 Crimes","Concha y Toro",
                "Antinori","Symington","Villa Maria","Vega Sicilia","Cloudy Bay"};
        int promedio=0;
        // 1.
        for (int i=0; i<calificacionVino.length;i++){
            promedio += calificacionVino[i];
        }
        promedio= promedio/calificacionVino.length;
        System.out.println("El puntaje promedio fue: "+ promedio);


        // 2.
        int contador=0,porcentajeBueno;
        for (int i=0; i<promediosVino.length;i++){
            if (promediosVino[i]>79 && promediosVino[i]<85){
                contador +=1;
            }
        }
        porcentajeBueno=contador*100/promediosVino.length;
        System.out.println("El " + porcentajeBueno+"% de vinos está en la escala de Bueno");

        // 3.
        System.out.println("Los siguientes vinos se encuentran en la escala Excepcional o Muy Bueno:");
        for (int i=0; i<promediosVino.length;i++){
            if (promediosVino[i]>84 && promediosVino[i]<95){
                System.out.println(nombreVino[i]);
            }
        }

    }

}
