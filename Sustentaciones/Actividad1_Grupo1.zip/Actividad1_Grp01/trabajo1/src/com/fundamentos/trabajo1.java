package com.fundamentos;

import java.util.Scanner;

public class trabajo1 {
    /* Se realizará un programa en el cual se debe
       medir el nivel de ruido e identifcar en que zona es
       permitido a través de un sonómetro (indicador de colores)
       que es representando por letras.
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        int nivel_r;//Declaro la variable de tipo entero
        String color_iden;//Declaro la variable de tipo char
        System.out.print("Medir nivel de ruido:  ");
        nivel_r = scanner.nextInt();//Ingreso el valor de la variable

        if (nivel_r <= 60 ){     // Si el nivel de ruido es menor o igual a 60 identificarlo con la letra (v)
            color_iden="verde";}     // que representa el color verde del sonómetro.

        else if ( nivel_r <= 70){// Si el nivel de ruido es menor o igual a 70 identificarlo con la letra (a)
            color_iden="amarillo";}     // que representa el color amarillo del sonómetro.

        else if ( nivel_r <= 80){// Si el nivel de ruido es menor o igual a 80 identificarlo con la letra (n)
            color_iden="naranja";}     // que representa el color naranja del sónometro.

        else{
            color_iden="rojo";}// Si el nivel de ruido es mayor a 80 identificarlo con la letra(r)
                            // que representa el color rojo del sonómetro


        switch (color_iden) {
            case "verde" -> System.out.println("Zona residencial");//Si el caso es la letra (v)se imprime zona residencial.
            case "amalliro" -> System.out.println("Zona comercial");//Si el caso es la letra (a)se imprime zona comercial.
            case "naranja" -> System.out.println("Zona industrial");//Si el caso es la letra (n)se imprime zona industrial.
            case "rojo" -> System.out.println("Zona contaminación sonora");//Si el caso es la letra (r)se imprime zona c.s.
        }
        /*case 'v':
                System.out.println("Zona residencial");
                break;
            case 'a':
                System.out.println("Zona comercial");
                break;
            case 'n':
                System.out.println("Zona industrial");
                break;
            case 'r':
                System.out.println("Zona contaminación sonora");
                break;

         */


    }
}