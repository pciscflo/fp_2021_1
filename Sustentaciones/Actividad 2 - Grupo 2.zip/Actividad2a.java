package com.fundamentos;

import java.util.Scanner;

public class Actividad2a {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingresa tu paquete adicional");
        String adicional = sc.nextLine();


        if (adicional.equals("MAX")) {
            System.out.println("El costo es de 10 soles adicionales");
        } else if (adicional.equals("FOX")) {
            System.out.println("El costo es de 15 soles adicionales");
        } else if (adicional.equals("HBO")) {
            System.out.println("El costo es de 20 soles adicionales");
        } else {
            System.out.println("Solo contamos con MAX, FOX o HBO.");
        }

    }
}

