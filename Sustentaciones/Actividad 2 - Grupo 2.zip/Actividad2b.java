package com.fundamentos;

import java.util.Scanner;

public class Actividad2b {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        System.out.println("Ingrese la empresa elegida:");
        String empresa = sc.nextLine();

        System.out.println("Ingresa el paquete a elegir:");
        String paquete = sc.nextLine();

        switch (empresa) {

            case "Movistar":
                System.out.println("Usted ha seleccionado empresa Movistar.");
                if (paquete.equalsIgnoreCase("Estandar")) {
                    System.out.println("Usted ha seleccionado el paquete Estandar.");
                    System.out.println("El monto a pagar es de 120 soles.");


                } else if (paquete.equalsIgnoreCase("Trío básico")) {
                    System.out.println("Usted ha seleccionado el paquete Trío básico.");
                    System.out.println("El monto a pagar es de 150 soles.");


                } else if (paquete.equalsIgnoreCase("Trío ilimitado")) {
                    System.out.println("Usted ha seleccionado el paquete Trío ilimitado.");
                    System.out.println("El monto a pagar es de 180 soles.");


                } else {
                    System.out.println("Solo contamos con paquete Estandar, Trío básico o Trío ilimitado.");
                }
                break;

            case "Claro":
                System.out.println("Usted ha seleccionado empresa Claro.");
                if (paquete.equalsIgnoreCase("Estandar")) {
                    System.out.println("Usted ha seleccionado el paquete Estandar.");
                    System.out.println("El monto a pagar es de 90 soles.");



                } else if (paquete.equalsIgnoreCase("Trío básico")) {
                    System.out.println("Usted ha seleccionado el paquete Trío básico.");
                    System.out.println("El monto a pagar es de 120 soles.");


                } else if (paquete.equalsIgnoreCase("Trío ilimitado")) {
                    System.out.println("Usted ha seleccionado el paquete Trío ilimitado.");
                    System.out.println("El monto a pagar es de 150 soles.");


                } else {
                    System.out.println("Solo contamos con paquete Estandar, Trío básico o Trío ilimitado.");
                }
                break;

            case "Entel":
                System.out.println("Usted ha seleccionado empresa Entel.");
                if (paquete.equalsIgnoreCase("Estandar")) {
                    System.out.println("Usted ha seleccionado el paquete Estandar.");
                    System.out.println("El monto a pagar es de 80 soles.");



                } else if (paquete.equalsIgnoreCase("Trío básico")) {
                    System.out.println("Usted ha seleccionado el paquete Trío básico.");
                    System.out.println("El monto a pagar es de 120 soles.");


                } else if (paquete.equalsIgnoreCase("Trío ilimitado")) {
                    System.out.println("Usted ha seleccionado el paquete Trío ilimitado.");
                    System.out.println("El monto a pagar es de 160 soles.");


                } else {
                    System.out.println("Solo contamos con paquete Estandar, Trío básico o Trío ilimitado.");
                }
                break;

            default:
                System.out.println("Solo trabajamos con Movistar, Claro o Entel.");


        }


    }

}
