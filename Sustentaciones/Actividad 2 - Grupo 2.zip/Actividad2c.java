package com.fundamentos;


import java.util.Scanner;

public class Actividad2c {

    public static void main(String[] args) {

        double precio_paquete;
        double precio_total;

        Scanner sc = new Scanner(System.in);

        System.out.printf("Ingrese la empresa elegida: ");
        String empresa = sc.nextLine();

        System.out.printf("Ingresa el paquete a elegir: ");
        String paquete = sc.nextLine();

        System.out.printf("Ingresa tu paquete adicional: ");
        String adicional = sc.nextLine();

        switch (empresa) {

            case "Movistar":
                System.out.printf("\nUsted ha seleccionado empresa Movistar.");
                if (paquete.equals("Estandar")) {
                    System.out.printf("\nUsted ha seleccionado el paquete Estandar.");
                    precio_paquete = 120;
                    precio_total = precio_paquete + calcular_adicional(adicional);
                    System.out.printf("\nEl monto a pagar es de %.2f soles", precio_total);


                } else if (paquete.equals("Trío básico")) {
                    System.out.printf("\nUsted ha seleccionado el paquete Trío básico.");
                    precio_paquete = 150;
                    precio_total = precio_paquete + calcular_adicional(adicional);
                    System.out.printf("\nEl monto a pagar es de %.2f soles", precio_total);


                } else if (paquete.equals("Trío ilimitado")) {
                    System.out.printf("\nUsted ha seleccionado el paquete Trío ilimitado.");
                    precio_paquete = 180;
                    precio_total = precio_paquete + calcular_adicional(adicional);
                    System.out.printf("\nEl monto a pagar es de %.2f soles", precio_total);


                } else {
                    System.out.printf("Solo contamos con paquete Estandar, Trío básico o Trío ilimitado.");
                }
                break;

            case "Claro":
                System.out.printf("\nUsted ha seleccionado empresa Claro.");
                if (paquete.equals("Estandar")) {
                    System.out.printf("\nUsted ha seleccionado el paquete Estandar.");
                    precio_paquete = 90;
                    precio_total = precio_paquete + calcular_adicional(adicional);
                    System.out.printf("\nEl monto a pagar es de %.2f soles", precio_total);


                } else if (paquete.equals("Trío básico")) {
                    System.out.printf("\nUsted ha seleccionado el paquete Trío básico.");
                    precio_paquete = 120;
                    precio_total = precio_paquete + calcular_adicional(adicional);
                    System.out.printf("\nEl monto a pagar es de %.2f soles", precio_total);


                } else if (paquete.equals("Trío ilimitado")) {
                    System.out.printf("\nUsted ha seleccionado el paquete Trío ilimitado.");
                    precio_paquete = 150;
                    precio_total = precio_paquete + calcular_adicional(adicional);
                    System.out.printf("\nEl monto a pagar es de %.2f soles", precio_total);


                } else {
                    System.out.printf("Solo contamos con paquete Estandar, Trío básico o Trío ilimitado.");
                }
                break;

            case "Entel":
                System.out.printf("\nUsted ha seleccionado empresa Entel.");
                if (paquete.equals("Estandar")) {
                    System.out.printf("\nUsted ha seleccionado el paquete Estandar.");
                    precio_paquete = 80;
                    precio_total = precio_paquete + calcular_adicional(adicional);
                    System.out.printf("\nEl monto a pagar es de %.2f soles", precio_total);


                } else if (paquete.equals("Trío básico")) {
                    System.out.printf("\nUsted ha seleccionado el paquete Trío básico.");
                    precio_paquete = 120;
                    precio_total = precio_paquete + calcular_adicional(adicional);
                    System.out.printf("\nEl monto a pagar es de %.2f soles", precio_total);


                } else if (paquete.equals("Trío ilimitado")) {
                    System.out.printf("\nUsted ha seleccionado el paquete Trío ilimitado.");
                    precio_paquete = 160;
                    precio_total = precio_paquete + calcular_adicional(adicional);
                    System.out.printf("\nEl monto a pagar es de %.2f soles", precio_total);


                } else {
                    System.out.printf("Solo contamos con paquete Estandar, Trío básico o Trío ilimitado.");
                }
                break;

            default:
                System.out.printf("Solo contamos con Movistar, Claro o Entel.");


        }

    }

    public static double calcular_adicional(String adicional) {

        double precio_paquete_adicional = 0;

        if (adicional.equals("MAX")) {
            System.out.printf("\nUsted ha seleccionado el adicional MAX.");
            precio_paquete_adicional = 10;
        } else if (adicional.equals("FOX")) {
            System.out.printf("\nUsted ha seleccionado el adicional FOX.");
            precio_paquete_adicional = 15;
        } else if (adicional.equals("HBO")) {
            System.out.printf("\nUsted ha seleccionado el adicional HBO.");
            precio_paquete_adicional = 20;
        } else {
            System.out.printf("Solo contamos con MAX, FOX o HBO.");
        }

        return precio_paquete_adicional;

    }


}
