package com.fundamentos;

import java.util.Scanner;

public class Actividad2d { //Nombre de una clase no debe ser un verbo.

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        System.out.println("Ingresa tu nota promedio: ");
        double nota = sc.nextDouble(); //Usamos  nota en vez de una sola letra (n)

        calculo_nota_alfabetico(nota);

    }

    //La siguiente función tiene un contexto con sentido.
    //la siguiente función no tiene como nombre codificación.
    public static void calculo_nota_alfabetico(double nota) { //nombre de metodo debe ser un verbo.

        if (nota <= 20 && nota >= 19) {
            System.out.println("Tienes un AD");
        } else if (nota < 19 && nota >= 17) {
            System.out.println("Tienes una A");
        } else if (nota < 17 && nota >= 15) {
            System.out.println("Tienes una B");
        } else if (nota < 15 && nota >= 13) {
            System.out.println("Tienes una C");
        } else if (nota < 13 && nota >= 11) {
            System.out.println("Tienes una D");
        } else {
            System.out.println("Jalaste el curso");
        }

    }

}

//Recordemos que debemos probar nuestro programa para que sea un código limpio.