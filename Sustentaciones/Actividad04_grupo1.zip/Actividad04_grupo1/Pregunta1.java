package com.fundamentos;

import java.util.Scanner;

public class Pregunta1 {
    static String [] codigos = {"PLIP1731P2143P3298BN008",
                                "SJLP1865P2266P3342BN015",
                                "VESP1756P2235P3321BN011",
                                "LINP1425P2586P3462BN019",
                                "JSMP1362P2689P3429BN007",
                                "PLIP1920P2353P3159BN005",
                                "PLIP1395P2666P3160BN013",
                                "JSMP1656P2431P3273BN016",
                                "LINP1227P2695P3663BN023",
                                "JSMP1860P2492P3109BN017"};
    public static void main(String[] args) {
        Scanner sc=new Scanner(System.in);
        String codigo, codigoDistrito,codigoDistritoCandidato,codigoCandidato;
        int cantidadVotosNulosOBlancos,cantidadCodigosDistrito,cantidadVotosCandidatoDistrito;
        System.out.print("Ingrese código: ");
        codigo= sc.next();
        cantidadVotosNulosOBlancos=obtenerCantidadVotosBlancoONulo(codigo);
        System.out.println("La cantidad de votos nulos o Blancos es " + cantidadVotosNulosOBlancos);
        System.out.print("Ingrese código del distrito: ");
        codigoDistrito= sc.next();
        cantidadCodigosDistrito=obtenerCantidadCodigosDeUnDistrito(codigos,codigoDistrito);
        System.out.println("La cantidad de codigos para el distrito "+ codigoDistrito+" es "+ cantidadCodigosDistrito);
        System.out.print("Ingrese código distrito candidato: ");
        codigoDistritoCandidato= sc.next();
        System.out.print("Ingrese código candidato: ");
        codigoCandidato= sc.next();
        cantidadVotosCandidatoDistrito=obtenerCantidadVotosCandidatoPorDistrito(codigos,codigoCandidato,codigoDistritoCandidato);
        System.out.println("La cantidad de votos que recibió ese candidato es "+ cantidadVotosCandidatoDistrito);

    }
    public static int obtenerCantidadVotosBlancoONulo (String codigo){
        int cantidadVotos=0;
        for (int i=0; i<codigos.length;i++){
            if (codigos[i].equals(codigo)){
                cantidadVotos=Integer.parseInt( codigos[i].substring(20,23));
            }
        }
        return cantidadVotos;
    }
    public static int obtenerCantidadCodigosDeUnDistrito(String []codigos,String codigoDistrito){
        int cantidadCodigos=0;
        for (int i=0;i<codigos.length;i++){
            if (codigos[i].substring(0,3).equals(codigoDistrito)){
                cantidadCodigos++;
            }
        }
        return cantidadCodigos;
    }
    public static int obtenerCantidadVotosCandidatoPorDistrito(String []codigos,String candidato,String codigoDistrito){
        int cantidadVotosCandidato=0;
        for (int i=0; i<codigos.length;i++){
            if (codigos[i].substring(0,3).equals(codigoDistrito) && codigos[i].substring(3,5).equals(candidato)){
                cantidadVotosCandidato=Integer.parseInt( codigos[i].substring(5,8))+cantidadVotosCandidato;
            }else if (codigos[i].substring(0,3).equals(codigoDistrito) && codigos[i].substring(8,10).equals(candidato)){
                cantidadVotosCandidato=Integer.parseInt( codigos[i].substring(10,13))+cantidadVotosCandidato;
            }else if (codigos[i].substring(0,3).equals(codigoDistrito) && codigos[i].substring(13,15).equals(candidato)){
                cantidadVotosCandidato=Integer.parseInt( codigos[i].substring(15,18))+cantidadVotosCandidato;
            }
        }
     return cantidadVotosCandidato;
    }
}
