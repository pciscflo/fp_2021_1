package com.fundamentos;

import java.util.Scanner;

public class Pregunta2 {

    static   String [] codigosTransacciones = {"302823511233ABCH12452018/08/29-17:01:33102",
                                               "303823511233ABCH12452018/08/31-11:01:33103",
                                               "302823511244ABCH12462018/08/31-14:05:32104",
                                               "303823511245ABCH12472018/08/31-16:01:33105",
                                               "302823511396ABCH12482018/08/31-22:09:33106",
                                               "303823511268ABCH12492018/08/31-23:50:20107",
                                               "303823511299ABCH12502018/08/31-23:56:17108"};

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        String codigoTransaccion, tipoTransaccion,operacionFrecuente,fecha,cuenta;
        String[]listadoTransaccionesFecha,listadoTransaccionesCuenta;
        System.out.print("Ingrese código de transacción: ");
        codigoTransaccion = sc.next();
        tipoTransaccion = saberTipoDeTransaccion(codigoTransaccion);
        System.out.println(tipoTransaccion);
        System.out.println("\n-----Operación más frecuente-------\n");
        operacionFrecuente=saberTipoOperacionMasFrecuente(codigosTransacciones);
        System.out.println(operacionFrecuente);
        System.out.print("\nIngrese fecha año/mes/día:");
        fecha=sc.next();
        System.out.print("\n");
        listadoTransaccionesFecha=obtenerListaDeTransacciones(fecha);
        for (int i=0; i< listadoTransaccionesFecha.length;i++){
            System.out.println(listadoTransaccionesFecha[i]);
        }
        System.out.print("\nIngrese n° cuenta : ");
        cuenta=sc.next();
        System.out.print("\n");
        listadoTransaccionesCuenta=obtenerListaDeTransaccionesCuenta(cuenta);
        for (int i=0; i< listadoTransaccionesCuenta.length;i++){
            System.out.println(listadoTransaccionesCuenta[i]);
        }

    }
     public static String saberTipoDeTransaccion (String codigoTransaccion){
        String mensaje=null;
        if("302".equals( codigoTransaccion.substring(0,3))){
             mensaje = "La transacción es de tipo afiliación.";
         }
        else if("303".equals(codigoTransaccion.substring(0,3))){
                mensaje= "La transacción es de tipo bloqueo.";
        }
     return mensaje;
    }
     public static String saberTipoOperacionMasFrecuente(String [] codigosTransacciones){
        String mensaje;
        int contadorA=0,contadorB=0;
        for (int i=0; i< codigosTransacciones.length;i++) {
            if ("302".equals(codigosTransacciones[i].substring(0, 3))) {
                contadorA++;
            } else if ("303".equals(codigosTransacciones[i].substring(0, 3))) {
                contadorB++;
            }
        }
        if (contadorA>contadorB){
            mensaje="La operación más frecuente es de afiliación(302).";
        }else if (contadorA<contadorB){
            mensaje="La operación más frecuente es de bloqueo(303).";
        }else{
            mensaje="Ambas operaciones, afiliación y bloqueo, son las más frecuentes.";
        }
      return mensaje;
     }
    public static String [] obtenerListaDeTransacciones(String fecha){
        String [] temporal= new String[codigosTransacciones.length];
        int j=0;
        for (int i = 0; i < codigosTransacciones.length; i++) {
            if (codigosTransacciones[i].substring(20,30).equals(fecha)) {
                temporal[j]=codigosTransacciones[i];
                j++;
            }
        }
        String[] arrF= new String[j];
        System.arraycopy(temporal,0,arrF,0,arrF.length);
        return arrF;
    }
    public static String [] obtenerListaDeTransaccionesCuenta(String cuenta){
        String [] temporal= new String[codigosTransacciones.length];
        int j=0;
        for (int i = 0; i < codigosTransacciones.length; i++) {
            if (codigosTransacciones[i].substring(3,12).equals(cuenta)) {
                temporal[j]=codigosTransacciones[i];
                j++;
            }
        }
        String[] arrF= new String[j];
        System.arraycopy(temporal,0,arrF,0,arrF.length);
        return arrF;
    }
}
