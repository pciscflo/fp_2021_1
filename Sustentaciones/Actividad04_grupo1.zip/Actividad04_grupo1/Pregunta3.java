package com.fundamentos;

public class Pregunta3 {
    static int [] TacamaCalificaciones = {88,79,91,60,78,99};

    static double [] promedioCalificacionesVinos={94.5,98.6,86.9,78.3,85.3,
                                                  56.1,55.9,77.2,62.1,99.2,
                                                  97.4,93.2,80.9,82.5,81.3,
                                                  58.7,61.4,69.8,73.1,83.9};

    static String [] vinosConcursantes={"Tabernero","Navarro","Queirolo","Intipalka","Marqués",
                                        "Frontera","Santa","Julia","Clos","ViñaVieja",
                                        "Benjamin","Rosé","Riscal","Tacama","Chenin",
                                        "Malbec","Inka","Senetiner","Oporto","Épico"};

    public static void main(String[] args) {

        double promedioCalificacionVino,porcentajeEscalaBueno;
        String [] listadoVinosExcepcionalOMuyBueno;
        System.out.println("Puntaje promedio para un vino");
        promedioCalificacionVino=obtenerPuntajePromedioCalificacion(TacamaCalificaciones);
        System.out.printf("\nEl puntaje promedio de ese vino es %.2f ", promedioCalificacionVino);
        System.out.println("\n\n--------------------------------------");
        porcentajeEscalaBueno=determinarPorcentajeDeEscalaDeBueno(promedioCalificacionesVinos);
        System.out.println("\nEl porcentaje de vinos que está en la escala BUENO es "+porcentajeEscalaBueno+" % .");
        System.out.println("\n--------------------------------------");
        listadoVinosExcepcionalOMuyBueno=obtenerListadoEscalaExcepcionalOMuyBueno(vinosConcursantes,promedioCalificacionesVinos);
        System.out.println("\nLos vinos que están en la escala Excepcional o Muy Bueno son los siguientes:\n ");
        for (int i=0; i< listadoVinosExcepcionalOMuyBueno.length;i++){
            System.out.println(listadoVinosExcepcionalOMuyBueno[i]);
        }


    }
    public static double obtenerPuntajePromedioCalificacion(int[] vinoCalificaciones){
        double sumaCalificacionVino=0,promedioCalificacionVino;
        for (int i=0; i<vinoCalificaciones.length;i++){
            sumaCalificacionVino=vinoCalificaciones[i]+sumaCalificacionVino;
        }
        promedioCalificacionVino=sumaCalificacionVino/vinoCalificaciones.length;
        return promedioCalificacionVino;
    }
    public static double determinarPorcentajeDeEscalaDeBueno(double[] promedioCalificacionesVinos){
      double  porcentajeEscala;
      int contadorEscala=0;
      for (int i=0;i<promedioCalificacionesVinos.length;i++){
          if (promedioCalificacionesVinos[i]>=80 && promedioCalificacionesVinos[i]<=84) {
              contadorEscala++;
          }
      }
        porcentajeEscala=contadorEscala*1.0*100/promedioCalificacionesVinos.length;
     return porcentajeEscala;
    }
   public static String [] obtenerListadoEscalaExcepcionalOMuyBueno (String[] vinosConcursantes, double[] promedioCalificacionesVinos ){
       String[] temporal=new String[promedioCalificacionesVinos.length];
       int j=0;
       for (int i=0; i<promedioCalificacionesVinos.length;i++){
           if (promedioCalificacionesVinos[i]>=85 && promedioCalificacionesVinos[i]<=94){
               temporal[j]=vinosConcursantes[i];
               j++;
           }
       }
       String[] arrF=new String[j];
       System.arraycopy(temporal,0,arrF,0,arrF.length);
       return arrF;
   }
}
